<?php 
class Model extends Db {
}