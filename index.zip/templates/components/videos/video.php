<div class="video-button" data-aperture="closed">
    <div class="video-container" >
        <video class="actual-video" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/502545/Oculus.mp4">
        </video>
        <div class="play-button__aperture--left"></div>
        <div class="play-button__aperture--top-right"></div>
        <div class="play-button__aperture--bottom-right"></div>
    </div>
</div>