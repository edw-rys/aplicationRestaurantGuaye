

    <script src="<?php echo JS?>index.js"></script>
    <script type="text/javascript" src="<?php echo JS?>validaciones.js"></script>
    <script type="text/javascript" src="<?php echo JS?>activeForm.js"></script>
    <script type="text/javascript" src="<?php echo JS?>server/user.functions.js"></script>
    <script type="text/javascript" src="<?php echo JS?>server/blog.functions.js"></script>
    <script type="text/javascript" src="<?php echo JS?>server/event.functions.js"></script>
    <?php if(isset($_SESSION["rol"]) && $_SESSION["rol"]==ADMINISTRADOR){?>
    <script src="<?php echo JS."server/dailymenu.functions.js"?>"></script>
    <?php }?>
    <!-- icons favicon -->
    <div class="hidden">Icons made by <a href="https://www.flaticon.es/autores/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.es/"             title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/"             title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
    <div class="hidden">Icons made by <a href="https://www.flaticon.es/autores/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.es/"             title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/"             title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
    <div class="hidden">Icons made by <a href="https://www.flaticon.es/autores/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.es/"             title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/"             title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
    <div class="hidden">Icons made by <a href="https://www.flaticon.es/autores/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.es/"             title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/"             title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>
    </body>
</html>

<!-- <a href="#!" onclick="window.scrollTo(0,0);" class="btn-up btn-first"><i class="fas fa-chevron-up"></i></a> -->

