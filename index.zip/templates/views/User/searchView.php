<header>
<?php include_once NAVIGATION?>
</header>

<div class="despliegue"></div>
<main class="search-container center">
    <h2 class="txt-center">Búsqueda</h2>
    <div class="content-seacrh" id="container-seach-user">
        <?php include_once COMPONENTS."user/panelSearch.php";  ?>
    </div>
</main>