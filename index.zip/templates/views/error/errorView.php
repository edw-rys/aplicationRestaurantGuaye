<!-- header -->
<header>
	<?php require_once NAVIGATION; ?>
</header>
<div class="m-t-80"></div>
<div class="_window_404 center">
    <div class="picture_ flex-center">
        <img src="<?php echo IMAGES?>bck/404.png" alt="error 404">
    </div>
    <div class="m-20"></div>
    <div class="_body">
        <p class="Montserrat-Bold p_404 txt-first txt-center">ERROR 404</p>
        <p class="Montserrat-Bold pagenotfound txt-first txt-center">Página no encontrada</p>

    </div>
    <div class="m-t-80"></div>    
</div>
<?php include_once INCLUDES ."footerhtml.php"?>