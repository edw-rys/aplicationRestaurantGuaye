<div class="flex-center flex-y" style="margin:70px auto">
	
	<div class="flex"> 
	  <div class="box-animation">
	    <div class="spinner-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="throbber-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="refreshing-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="heartbeat-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="gauge-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="three-quarters-loader"> </div>
	  </div>
	</div>
	<div class="flex">
	  <div class="box-animation">
	    <div class="wobblebar-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="atebits-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="whirly-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="flower-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="dots-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="circles-loader"> </div>
	  </div>
	</div>
	<div class="flex">
	  <div class="box-animation">
	    <div class="plus-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="pulse-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="hexdots-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="inner-circles-loader"> </div>
	  </div>
	  <div class="box-animation">
	    <div class="pong-loader"></div>
	  </div>
	  <div class="box-animation">
	    <div class="timer-loader"></div>
	  </div>
	</div>
	<div class="flex"> 
	  <div class="box-animation">
	    <div class="ball-loader"></div>
	  </div>
	</div>
</div>