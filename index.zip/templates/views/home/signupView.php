<header>
    <?php require_once NAVIGATION; ?>
</header>

<div class="despliegue"></div>
<div class="flex-center">
<?php include_once COMPONENTS."user/signupComponent.php" ?>
</div>